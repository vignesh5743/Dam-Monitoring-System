"This file defines the colors tuples"

# white
white = (255, 255, 255)

# black
black = (0, 0, 0)

# red color
red = (255, 0, 0)

# different transparent red degrees
red1L = (255, 26, 26)
red2L = (255, 51, 51)
red3L = (255, 77, 77)
red4L = (255, 102, 102)
red5L = (255, 128, 128)
red6L = (255, 153, 153)

# green
green = (0, 255, 0)

# blue
blue = (0, 0, 255)
