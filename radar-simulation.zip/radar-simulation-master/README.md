# Radar Simulation

## Description
A part of my graduation project that simulates the radar using hc-sr04 ultrasonic sensor on a servo motor rotating from 0 degree to 180 degree

## Hardware Components
* Raspberry Pi 3 Model B
* HC-SR04 sensor
* Servo Motor

## Circuit Diagram For Connecting Ultrasonic Sensor
![Circuit Diagram](/circuit_diagram.png)

## Software Requirements
* python 2.7
* pygame library for drawing the radar screen

## How to run
run `python radar.py`

## Preview Video
Watch Video on [youtube](https://youtu.be/kzpTUnOJpF8)
